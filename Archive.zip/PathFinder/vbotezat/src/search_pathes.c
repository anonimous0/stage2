#include "../inc/pathfinder.h"
int add_index_pathes(t_path **path) {
    t_path *indexed = *path;
    t_path *bonds = NULL;
    int i = 0;

    for (; indexed; indexed = indexed->nextPath) {
        bonds = indexed;

        while (bonds) {
            bonds->index = i;
            bonds = bonds->nextConnect;
        }

        i++;
    }

    return i;
}
t_island *shortest_distance(t_island **unvisited) {
    t_island *head = NULL;
    t_island *shortest = NULL;

    if (unvisited || *unvisited) {
        head = *unvisited;
        shortest = *unvisited;

        while (head) {
            if (head->distTo != 0) {
                if (shortest->distTo > head->distTo || !shortest->distTo) {
                    shortest = head;
                }
            }

            head = head->next;
        }
    }

    return shortest;
}
static void compare(t_path **newOne, t_path **curOne, int *flag) {
    if (*newOne && *curOne) {
        if ((*newOne)->idPath != (*curOne)->idPath) {
            *flag = 1;
        }
        if ((*newOne)->distPath != (*curOne)->distPath) {
            *flag = 1;
        }
    }
    if (!(*newOne) || !(*curOne)) {
        *flag = 1;
    }
}

static void step(t_path **oldOne, t_path **path, t_path **new) {
    *path = *new;
    *oldOne = (*oldOne)->nextPath;
}

int unique_path(t_path **new, t_path **current) {
    t_path *path = *new;
    t_path *oldOne = *current;
    int flag = -1;

    while (oldOne) {
        if (oldOne->nextConnect == NULL || !path) {
            compare(&path, &oldOne, &flag);
            step(&oldOne, &path, &(*new));

            if (flag == -1) {
                return -1;
            }
            if (oldOne) {
                flag = -1;
            }

            continue;
        }

        compare(&path, &oldOne, &flag);

        path = path->nextConnect;
        oldOne = oldOne->nextConnect;
    }

    return flag;
}
void path_push_back(t_path **path, t_path **previous, int isl, int dist) {
    t_path *last = *path;
    t_path *cur = *previous;
    t_path *new = NULL;

    while (last->nextPath != NULL) {
        last = last->nextPath;
    }
    while (cur) {
        new = add_one_path(&cur, isl, dist);

        if (unique_path(&new, &(*path)) == 1) {
            add_link(&last, &new);

            last = last->nextPath;
        }

        cur = cur->nextPath;
    }
}

void add_link(t_path **cur, t_path **new) {
    t_path *current = *cur;

    while (current->nextConnect) {
        current->nextPath = *new;
        current = current->nextConnect;
    }

    current->nextPath = *new;
}
static void firs_if (t_island *temp, t_island *leftOne, int index) {
    if (temp && temp->indexIsland == index) {
        if (temp->next) {
            leftOne->next = temp->next;
        }
        else {
            leftOne->next = NULL;
        }

        delete_path(&temp->path);
        free(temp);

        temp = NULL;
    }
}

void island_pop_middle(t_island **unvisited, int index) {
    t_island *temp = NULL;
    t_island *leftOne = NULL;

    if (!unvisited || !(*unvisited)) {
        return;
    }
    if ((*unvisited)->indexIsland == index) {
        delete_path(&((*unvisited)->path));
        island_pop_front(&(*unvisited));
    }
    else {
        temp = *unvisited;
        leftOne = temp;

        while (temp != NULL && temp->indexIsland != index) {
            leftOne = temp;
            temp = temp->next;
        }

        firs_if (temp, leftOne, index);
    }
}

void island_pop_front(t_island **head) {
    t_island *p = NULL;

    if (!head || !(*head)) {
        return;
    }
    if ((*head)->next == NULL) {
        free(*head);

        *head = NULL;

        return;
    }
    else {
        p = (*head)->next;

        free(*head);

        *head = p;
    }
}
void delete_mat(int ***matrix, char **set) {
    int **mat = *matrix;
    int i = 0;

    while (set[i]) {
        i++;
    }

    while (i >= 0) {
        free(*mat);

        mat++;
        i--;
    }

    free(*matrix);

    *matrix = NULL;
}
static void pop_all_bond(t_path **head) {
    t_path *p = NULL;

    if (!head || !(*head)) {
        return;
    }

    while ((*head)->nextConnect) {
        p = (*head)->nextConnect;

        free(*head);

        *head = p;
    }

    if (!(*head)->nextConnect && !(*head)->nextPath) {
        free(*head);

        *head = NULL;

        return;
    }
}

static void pop_next_path(t_path **head) {
    t_path *p = NULL;

    if (!head || !(*head)) {
        return;
    }
    if ((*head)->nextPath == NULL) {
        free(*head);

        *head = NULL;

        return;
    }
    else {
        p = (*head)->nextPath;

        free(*head);

        *head = p;
    }
}

void delete_path(t_path **head) {
    if (!head || !(*head)) {
        return;
    }

    while (*head) {
        pop_all_bond(&(*head));
        pop_next_path(&(*head));
    }
}
t_path *add_one_path(t_path **previous, int isl, int dist) {
    t_path *new = NULL;
    t_path *last = *previous;
    t_path *res = NULL;

    if (!last) {
        return res = create_path(isl, dist);
    }

    res = create_path(last->idPath, last->distPath);
    new = res;
    last = last->nextConnect;

    while (last) {
        new->nextConnect = create_path(last->idPath, last->distPath);
        last = last->nextConnect;
        new = new->nextConnect;
    }

    new->nextConnect = create_path(isl, dist);

    return res;
}
t_path *add_path(t_path **previous, int isl, int dist) {
    t_path *cur = NULL;
    t_path *res = NULL;
    t_path *new = NULL;
    t_path *fast = NULL;

    if (*previous) {
        cur = *previous;
    }

    res = add_one_path(&cur, isl, dist);
    fast = res;

    if (cur) {
        cur = cur->nextPath;
    }

    while (cur) {
        new = add_one_path(&cur, isl, dist);

        add_link(&fast, &new);

        fast = fast->nextPath;
        cur = cur->nextPath;
    }

    return res;
}
t_island *create_island(int isl, int dist) {
    t_island *node = (t_island *)malloc(1 * sizeof(t_island));

    node->indexIsland = isl;
    node->distTo = dist;
    node->path = NULL;
    node->next = NULL;

    return node;
}
t_li *create_l() {
    t_li *l = malloc(sizeof(t_li));

    l->un = NULL;
    l->v = NULL;
    l->cur = NULL;
    l->sh = NULL;

    return l;
}
t_path *create_path(int isl, int dist) {
	t_path *node = (t_path *)malloc(1 * sizeof(t_path));

	node->idPath = isl;
	node->distPath = dist;
	node->nextConnect = NULL;
	node->nextPath = NULL;

	return node;
}
static t_path *add_one(t_path **previous) {
    t_path *new = NULL;
    t_path *last = *previous;
    t_path *res = NULL;

    res = create_path(last->idPath, last->distPath);
    new = res;
    last = last->nextConnect;

    while (last) {
        new->nextConnect = create_path(last->idPath, last->distPath);
        last = last->nextConnect;
        new = new->nextConnect;
    }

    return res;
}

t_path *copy_path(t_path **data) {
    t_path *cur = NULL;
    t_path *res = NULL;
    t_path *new = NULL;
    t_path *fast = NULL;

    if (*data) {
        cur = *data;
    }

    res = add_one(&cur);
    fast = res;
    cur = cur->nextPath;

    while (cur) {
        new = add_one(&cur);

        add_link(&fast, &new);

        fast = fast->nextPath;
        cur = cur->nextPath;
    }

    return res;
}
void pbi(t_island **island, t_path **path, int isl, int dist) {
    t_island *new = create_island(isl, dist);
    t_island *last = *island;

    if (path && *path) {
        new->path = copy_path(&(*path));
    }
    if (*island == NULL) {
        *island = new;

        return;
    }

    while (last->next != NULL) {
        last = last->next;
    }

    last->next = new;

    return;
}
static void st(t_island **un, t_island **cur, t_island **v, t_int *in) {
    *un = NULL;
    *v = NULL;

    for (int i = 0; i < in->size; i++) {
        pbi(&(*un), NULL, i, 0);
    }

    *cur = *un;

    while ((*cur)->indexIsland != in->root) {
        *cur = (*cur)->next;
    }

    (*cur)->path = create_path(in->root, 0);

    pbi(&(*v), &(*cur)->path, (*cur)->indexIsland, (*cur)->distTo);
    island_pop_middle(&(*un), in->root);

    *cur = *v;
}

static void md (t_island **un, t_island **cur, int **mat, t_md **m) {
    t_island *h = *un;
    int sum = 0;

    while (h != NULL) {
        (*m)->isl1 = (*cur)->indexIsland;
        (*m)->isl2 = h->indexIsland;
        (*m)->mat = mat[(*m)->isl1][(*m)->isl2];

        if ((*m)->mat != 0 && h->distTo == 0) {
            h->distTo = (*cur)->distTo + (*m)->mat;
            sum += h->distTo;

            if (sum < 0) {
                mx_printerr("error: sum of bridges lengths is too big");
                exit(0);
            }

            h->path = add_path(&(*cur)->path, (*m)->isl2, (*m)->mat);
        } else if ((*m)->mat != 0) {
            if ((*cur)->distTo + (*m)->mat == h->distTo) {
                path_push_back(&h->path, &(*cur)->path, (*m)->isl2, (*m)->mat);
            }

            if ((*cur)->distTo + (*m)->mat < h->distTo) {
                h->distTo = (*cur)->distTo + (*m)->mat;

                delete_path(&h->path);
                h->path = add_path(&(*cur)->path, (*m)->isl2, (*m)->mat);

            }
        }

        h = h->next;
    }
}

static void lt(t_li **l, int **matrix, char **set) {
    (*l)->sh = shortest_distance(&(*l)->un);

    pbi(&(*l)->v, &(*l)->sh->path, (*l)->sh->indexIsland, (*l)->sh->distTo);
    island_pop_middle(&(*l)->un, (*l)->sh->indexIsland);

    (*l)->cur = (*l)->cur->next;

    if ((*l)->cur->path == NULL) {
        delete_mat(&matrix, set);
        mx_printerr("error: invalid number of islands");
        exit(0);
    }
}

static void main_algo(int **matrix, char **set, t_int *in) {
    t_li *l = create_l();
    t_md *m	= NULL;

    st(&l->un, &l->cur, &l->v, in);

    while (l->un && l->un != NULL) {
        m = malloc(sizeof(t_md));

        md(&l->un, &l->cur, matrix, &m);
        free(m);

        m = NULL;

        lt(&l, matrix, set);
    }

    print_output(&l->v, in->root+1, in->size, set);

    while (l->v != NULL) {
        delete_path(&l->v->path);
        island_pop_front(&l->v);
    }

    free(l);

    l = NULL;
}

void algorithm(int **matrix, char **set) {
    int size = 0;
    int i = 0;
    t_int *in = malloc(sizeof(t_int));

    while (set[size]) {
        size++;
    }

    in->size = size;

    while (i < size - 1) {
        in->root = i;

        main_algo(matrix, set, in);

        i++;
    }

    free(in);

    in = NULL;
}
