#include "../inc/pathfinder.h"
static void check_island12(char *island1, char *island2, char *dis, int nline) {
    if (mx_strcmp(island1, island2) == 0 && mx_atoi(dis) != 0) {
        nline++;

        mx_printerr("error: line ");
        mx_printerr(mx_itoa(nline));
        mx_printerr(" is not valid");
        exit(0);
    }
}

static void linearr(char *line, char **island1, char **island2, char **dis) {
    int i = 0;
    char *str = line;

    while (str[i] != '-') {
        i++;
    }

    *island1 = mx_strndup(str, i);

    str += i + 1;
    i = 0;

    while (str[i] != ',') {
        i++;
    }

    *island2 = mx_strndup(str, i);

    str += i + 1;
    i = 0;

    while (str[i] != '\0') {
        i++;
    }

    *dis = mx_strndup(str, i);
}

static void fill_islands(char ***arrarr, char **lines, int line) {
    char **arr = *arrarr;
    char *island1 = NULL;
    char *island2 = NULL;
    char *dist = NULL;
    int arr_indicator = 0;

    while (lines[line]) {
        linearr(lines[line], &island1, &island2, &dist);
        check_island12(island1, island2, dist, line);

        // Write first island
        arr[arr_indicator++] = mx_strdup(island1);
        mx_strdel(&island1);

        // Write second island
        arr[arr_indicator++] = mx_strdup(island2);
        mx_strdel(&island2);

        // Write distance
        arr[arr_indicator++] = mx_strdup(dist);
        mx_strdel(&dist);

        // Check for duplicate bridges
        for (int i = 0; i < arr_indicator - 3; i += 3) {
            if (mx_strcmp(arr[arr_indicator - 3], arr[i]) == 0 &&
                mx_strcmp(arr[arr_indicator - 2], arr[i + 1]) == 0) {
                mx_printerr("error: duplicate bridges");
                exit(0);
            }
            if (mx_strcmp(arr[arr_indicator - 2], arr[i]) == 0 &&
                mx_strcmp(arr[arr_indicator - 3], arr[i + 1]) == 0) {
                mx_printerr("error: duplicate bridges");
                exit(0);
            }
        }

        line++;
    }
}

void create_arr(char **lines, char ***arrarr) {
    int line = 1;

    while (lines[line]) {
        line++;
    }

    *arrarr = (char **)malloc((line * 3 + 1) * sizeof(char *));

    fill_islands(&(*arrarr), lines, 1);
}
static void count_err(int count, char *nIslands) {
    if (count == 0 || count != mx_atoi(nIslands) || count == 1) {
        mx_printerr("error: invalid number of islands");
        exit(0);
    }
}

static int count_set(char **arr, char *nIslands) {
    int count = 0;
    int j = 0;

    if (arr && *arr) {
        if (arr[0]) {
            count++;
        }

        for (int i = 1; arr[i] != NULL; i++) {
            if (mx_isdigit(arr[i][0])) {
                i++;
            }
            if (arr[i] == NULL) {
                break;
            }

            for (j = i - 1; j >= 0; j--) {
                if (mx_strcmp(arr[i], arr[j]) == 0) {
                    break;
                }
                if (j == 0) {
                    count++;
                }
            }
        }
    }

    count_err(count, nIslands);

    return count;
}

static int crflag(char *arr, char **set1) {
    int j = 0;
    int flag = 0;

    while (set1[j]) {
        if (mx_strcmp(arr, set1[j]) == 0) {
            flag++;

            break;
        }

        j++;
    }

    return flag;
}


static void crset(char ***set, char ***arrarr) {
    char **arr = *arrarr;
    char **set1 = *set;
    int i = 0;

    for (int flag = 0; *arr; flag = 0) {
        if (mx_isdigit(**arr)) {
            arr++;
        }
        if (*arr) {
            flag = crflag(*arr, set1);

            if (flag != 0) {
                arr++;

                continue;
            }
            if (flag == 0) {
                set1[i] = mx_strdup(*arr);
                set1[i + 1] = NULL;
                i++;
            }

            arr++;
        }
    }
}

void create_set(char ***set, char ***arrarr, char *nIslands) {
    int count = count_set(*arrarr, nIslands);
    *set = (char **)malloc((count + 1) * sizeof(char *));
    **set = NULL;

    crset(&(*set), &(*arrarr));
}

void parsing(char *fd, int ***matrix, char ***set) {
    char **arrarr = NULL;
    char **src = mx_strsplit(fd, '\n');

    create_arr(src, &arrarr);
    create_set(&(*set), &arrarr, src[0]);

    *matrix = create_matrix(*set, &arrarr);

    mx_del_strarr(&src);
    mx_del_strarr(&arrarr);
}
