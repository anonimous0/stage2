#include "../inc/pathfinder.h"
void join(char **res, char *s2) {
    char *newstr = mx_strnew(mx_strlen(*res) + mx_strlen(s2));
    int i = 0;
    int si = -1;
    char *s1 = *res;

    while (s1[++si]) {
        newstr[i] = s1[si];
        i++;
    }

    si = -1;

    while (s2[++si]) {
        newstr[i] = s2[si];
        i++;
    }

    mx_strdel(&(*res));

    *res = newstr;
}
static void print_line(t_char **prd) {
    char *string = mx_strdup("========================================");

    mx_printstr(string);
    mx_printchar('\n');
    mx_printstr((*prd)->p);
    mx_printstr((*prd)->r);
    mx_printstr((*prd)->d);
    mx_printstr(string);
    mx_printchar('\n');
    mx_strdel(&(*prd)->p);
    mx_strdel(&(*prd)->r);
    mx_strdel(&(*prd)->d);
    mx_strdel(&string);

    free(*prd);

    *prd = NULL;
}

static t_char *createprd(t_path *bond, char **set) {
    t_char *prd = malloc(1 * sizeof(t_char));
    int i = 0;

    prd->p = mx_strdup("Path: ");

    join(&(*prd).p, set[bond->idPath]);

    prd->r = mx_strdup("Route: ");

    join(&(*prd).r, set[bond->idPath]);

    prd->d = mx_strdup("Distance: ");

    for (; bond; bond = bond->nextConnect) {
        i++;
    }

    prd->s = i;

    return prd;
}

static void add_next_bond(t_char **prd, t_path *bond, char *distTo, char **set) {
    char *dist = mx_itoa(bond->distPath);

    join(&(*prd)->r, " -> ");
    join(&(*prd)->r, set[bond->idPath]);

    if (mx_strlen((*prd)->d) != 10) {
        join(&(*prd)->d, " + ");
    }

    join(&(*prd)->d, dist);
    mx_strdel(&dist);

    if (bond->nextConnect == NULL) {
        join(&(*prd)->p, " -> ");
        join(&(*prd)->p, set[bond->idPath]);

        if ((*prd)->s != 2) {
            join(&(*prd)->d, " = ");
            join(&(*prd)->d, distTo);
        }

        join(&(*prd)->r, "\n");
        join(&(*prd)->p, "\n");
        join(&(*prd)->d, "\n");
    }
}

static void display_path(t_path **disp, int distTo, char **set) {
    t_path *bond = *disp;
    t_char *prd = NULL;
    char *dist = mx_itoa(distTo);

    while (bond) {
        prd = createprd(bond, set);
        bond = bond->nextConnect;

        while (bond->nextConnect) {
            add_next_bond(&prd, bond, dist, set);

            bond = bond->nextConnect;
        }

        add_next_bond(&prd, bond, dist, set);
        print_line(&prd);

        bond = bond->nextPath;
    }

    mx_strdel(&dist);
}
static int cmp(t_path *bond, t_path *fast) {
    while (bond && fast) {
        if (bond->idPath > fast->idPath) {
            return 1;
        }
        if (bond->idPath < fast->idPath) {
            return 0;
        }

        bond = bond->nextConnect;
        fast = fast->nextConnect;
    }

    if (bond && !fast) {
        return 1;
    }

    return 0;
}

static void swp_d(t_path **disp, t_path **bond, t_path **fast) {
    t_path *temp = (*fast)->nextPath;
    t_path *cur = *disp;

    while (cur->nextPath != *fast) {
        cur = cur->nextPath;
    }

    add_link(&cur, &(*bond));

    cur = *disp;

    if (*disp == *bond) {
        *disp = *fast;
    }
    else {
        while (cur && cur->nextPath != *bond) {
            cur = cur->nextPath;
        }

        add_link(&cur, &(*fast));
    }

    add_link(&(*fast), &(*bond)->nextPath);
    add_link(&(*bond), &temp);
}

static void swp(t_path **disp, t_path **bond, t_path **fast) {
    t_path *temp = (*fast)->nextPath;
    t_path *cur = *disp;

    if ((*bond)->nextPath == *fast) {
        add_link(&(*fast), &(*bond));
        add_link(&(*bond), &temp);

        if (*disp == *bond) {
            *disp = *fast;
        }
        else {
            while (cur && cur->nextPath != *bond) {
                cur = cur->nextPath;
            }

            add_link(&cur, &(*fast));
        }
    }
    else {
        swp_d(&(*disp), &(*bond), &(*fast));
    }
}

void sort_path(t_path **disp, int sizeP) {
    t_path *bond = *disp;
    t_path *fast = (*disp)->nextPath;

    for (int i = 0; i < sizeP; i++) {
        bond = *disp;
        fast = bond->nextPath;

        for (; bond->index != i; bond = bond->nextPath) {
            fast = bond->nextPath;
        }

        while (fast) {
            if (cmp(bond, fast) == 1) {
                swp(&(*disp), &bond, &fast);

                for (bond = *disp; bond->index != i; bond = bond->nextPath) {
                    fast = bond->nextPath;
                }
            }
            else {
                fast = fast->nextPath;
            }
        }
    }
}
void print_output(t_island **visited, int root, int size, char **set) {
    t_island *current = NULL;
    int sizeP;

    for (; root < size; root++) {
        current = *visited;

        while (current->indexIsland != root) {
            current = current->next;
        }

        sizeP = add_index_pathes(&current->path);

        sort_path(&current->path, sizeP);
        display_path(&current->path, current->distTo, set);
    }
}
