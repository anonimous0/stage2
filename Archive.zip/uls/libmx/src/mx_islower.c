#include "libmx.h"

bool mx_islower(int c){
	return (c>=97&&c<=122);
}
