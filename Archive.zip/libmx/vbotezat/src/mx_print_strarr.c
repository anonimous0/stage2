#include "libmx.h"

void mx_print_strarr (char **arr, const char *delim) {
    int i = 0;
    if (arr == NULL || delim == NULL)
        return;
    while (*arr[i] != NULL){
        mx_printstr(arr[i]);
        if (*arr[i + 1] == '\0')
            break;
		mx_printchar(*delim);
        i++;
    }
    mx_printchar('\n');
}
