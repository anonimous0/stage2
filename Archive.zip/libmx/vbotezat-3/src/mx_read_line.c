#include "libmx.h"

int mx_read_line(char **lineptr, size_t buf_size, char delim, const int fd) {
    char *temp_str = NULL;
    char buff[buf_size + 1];
    int index_of_delim;
    int x = 0;
    int i = 1;
    static char *static_str = NULL;
    int len_of_static = 0;

    bool find_delim = false;
    buff[buf_size] = '\0';
    temp_str = (char *)malloc(sizeof(char) * (buf_size + 1) * i);
    temp_str[buf_size] = '\0';

    if (static_str != NULL){
        index_of_delim = mx_get_char_index(static_str, delim);
        len_of_static = mx_strlen(static_str);

        temp_str = (char *)mx_realloc(temp_str, sizeof(char) * (buf_size) * i + len_of_static);

        mx_strcat(temp_str, static_str);

        if (index_of_delim >= 0) {
            free(*lineptr);
        	(*lineptr) = mx_strnew(index_of_delim + 1);
            for (int j = 0; j < index_of_delim; j++) {
                (*lineptr)[j] = static_str[j];
            }
            if (static_str != NULL) {
                free(static_str);
                static_str = mx_strnew(buf_size + 1);
            }
            for (int k = index_of_delim; temp_str[k]; k++) {
                static_str[x] = temp_str[k + 1];
                x++;
            }
            free(temp_str);
            return index_of_delim;
        }
    }

    free(static_str);
    static_str = mx_strnew(buf_size + 1);

    while(!find_delim) {
        temp_str = (char *)mx_realloc(temp_str, sizeof(char) * (buf_size) * i + len_of_static);

        if (read(fd, buff, buf_size)) {}
        else {
            return -1;
        }

        mx_strcat(temp_str, buff);
        index_of_delim = mx_get_char_index(temp_str, delim);

        if (index_of_delim >= 0) {
            free(*lineptr);
        	(*lineptr) = mx_strnew(index_of_delim + 1);
            for (int j = 0; j < index_of_delim; j++) {
                (*lineptr)[j] = temp_str[j];
            }
            if (static_str != NULL) {
                free(static_str);
                static_str = mx_strnew(buf_size + 1);
            }
            for (int k = index_of_delim; temp_str[k]; k++) {
                static_str[x] = temp_str[k + 1];
                x++;
            }
            find_delim = true;
        }
        else {
            i++;
        }
    }
    free(temp_str);
    return index_of_delim;
}
